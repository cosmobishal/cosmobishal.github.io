# Assets Folder

This folder is for storing additional files and resources:

## What to Add Here

### Documents
- Research papers (PDF)
- CV/Resume (PDF)
- Presentations (PDF, PPTX)
- Project reports
- Certificates (PDF)

### Data Files
- Research datasets (CSV, JSON)
- Code samples
- Configuration files

### Other Resources
- Downloadable materials
- Supplementary files for publications

## Usage

Once you add files here, you can link to them from your portfolio:

```html
<!-- Example: Link to CV -->
<a href="assets/cv-bishal-neupane.pdf" download>Download CV</a>

<!-- Example: Link to research paper -->
<a href="assets/exoplanet-habitability-paper.pdf" target="_blank">View Paper</a>
```

## File Organization Tips

Consider creating subfolders for better organization:
```
assets/
├── documents/
│   ├── cv.pdf
│   └── resume.pdf
├── papers/
│   ├── paper-2025-habitability.pdf
│   └── paper-2025-characterization.pdf
├── presentations/
│   └── iau-workshop-2025.pdf
└── data/
    └── exoplanet-catalog.csv
```

---

**Note**: This folder is currently empty. Add your files before linking to them in your portfolio.
