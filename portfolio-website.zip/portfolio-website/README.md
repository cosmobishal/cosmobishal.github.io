# Bishal Neupane - Astrophysicist Portfolio Website

A fully interactive, astronomical-themed portfolio website showcasing research, experience, certifications, and publications in astronomy and space science.

## 🌌 Features

- **Animated Starfield Background**: Interactive canvas-based star animation with nebulae, shooting stars, and constellations
- **Glitch Effect Header**: Eye-catching text animation with cyberpunk aesthetic
- **Typing Animation**: Dynamic role descriptions with typewriter effect
- **Responsive Design**: Mobile-friendly layout that adapts to all screen sizes
- **Interactive Certifications Filter**: Filter 45+ certifications by category
- **Smooth Scrolling**: Animated navigation with active link highlighting
- **Planet System Animation**: 3D orbital visualization in the About section
- **Contact Form**: Functional contact form with validation
- **Timeline**: Professional experience displayed in an elegant timeline
- **Publication Cards**: Research papers with direct links

## 🚀 Technologies Used

- HTML5
- CSS3 (with advanced animations and gradients)
- Vanilla JavaScript (ES6+)
- Canvas API for starfield animation
- Google Fonts (Orbitron, Rajdhani, Space Mono)
- Font Awesome 6.4.0

## 📁 File Structure

```
portfolio-website/
├── index.html
├── css/
│   └── styles.css
├── js/
│   ├── main.js
│   ├── starfield.js
│   └── certifications.js
├── assets/
├── images/
└── README.md
```

## 🛠️ Setup Instructions

### For GitHub Pages Deployment

1. **Create a new repository**:
   - Go to GitHub and create a new repository named `username.github.io` (replace `username` with your GitHub username)

2. **Upload files**:
   ```bash
   git init
   git add .
   git commit -m "Initial commit: Portfolio website"
   git branch -M main
   git remote add origin https://github.com/cosmobishal/cosmobishal.github.io.git
   git push -u origin main
   ```

3. **Enable GitHub Pages**:
   - Go to repository Settings → Pages
   - Source: Deploy from a branch
   - Branch: main / (root)
   - Save

4. **Access your website**:
   - Your site will be available at `https://cosmobishal.github.io`

### Local Development

1. **Clone the repository**:
   ```bash
   git clone https://github.com/username/username.github.io.git
   cd username.github.io
   ```

2. **Open in browser**:
   - Simply open `index.html` in your web browser
   - Or use a local server (recommended):
   ```bash
   # Using Python 3
   python -m http.server 8000
   
   # Using Node.js (http-server)
   npx http-server
   ```

3. **Access locally**:
   - Navigate to `http://localhost:8000`

## 🎨 Customization

### Colors

Edit the CSS variables in `css/styles.css`:

```css
:root {
    --primary-color: #00d9ff;
    --secondary-color: #7000ff;
    --accent-color: #ff006e;
    --dark-bg: #0a0e27;
    /* ... */
}
```

### Content

- **Personal Information**: Edit `index.html` sections
- **Certifications**: Modify `js/certifications.js` array
- **Publications**: Update the publications section in `index.html`
- **Experience**: Edit timeline items in `index.html`

### Fonts

Change fonts in `css/styles.css`:
```css
@import url('your-google-fonts-url');
```

## 📱 Responsive Breakpoints

- Desktop: 1024px and above
- Tablet: 768px - 1023px
- Mobile: 480px - 767px
- Small Mobile: Below 480px

## ✨ Special Features

### Easter Egg
Try typing the Konami Code: ↑ ↑ ↓ ↓ ← → ← → B A

### Interactive Elements
- Click on email to copy to clipboard
- Hover effects on all cards and buttons
- Smooth parallax scrolling
- Constellation connections based on proximity

## 🔧 Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## 📄 License

This project is open source and available under the [MIT License](LICENSE).

## 🤝 Contributing

Contributions, issues, and feature requests are welcome!

## 👤 Author

**Bishal Neupane**
- ORCID: [0009-0005-9970-3666](https://orcid.org/0009-0005-9970-3666)
- LinkedIn: [@cosmobishal](https://www.linkedin.com/in/cosmobishal/)
- Location: Kathmandu, Nepal

## 🌟 Acknowledgments

- Inspired by the vastness of the cosmos
- Built with passion for astronomy and technology
- Designed to inspire the next generation of astronomers

---

⭐ **Star this repository if you found it helpful!**

🌌 **Exploring the cosmos, one line of code at a time...**
