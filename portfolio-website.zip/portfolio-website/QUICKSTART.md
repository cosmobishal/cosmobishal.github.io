# 🚀 QUICK START GUIDE

## Get Your Portfolio Online in 5 Minutes!

### Step 1: Download Files ✅
You already have all the files! The `portfolio-website` folder contains everything you need.

### Step 2: Create GitHub Account
If you don't have one:
1. Go to https://github.com
2. Click "Sign up"
3. Choose a username (this will be in your URL!)

### Step 3: Create Repository
1. Click the "+" icon (top right) → "New repository"
2. **Repository name**: `cosmobishal.github.io` 
   - ⚠️ MUST use this exact format!
3. Make it **Public**
4. Click "Create repository"

### Step 4: Upload Files

#### Option A: GitHub Website (Easiest)
1. Click "uploading an existing file"
2. Drag ALL files from portfolio-website folder
3. Scroll down, click "Commit changes"

#### Option B: GitHub Desktop (Recommended)
1. Download GitHub Desktop from https://desktop.github.com
2. Clone your repository
3. Copy all files from portfolio-website to the repository folder
4. Commit and push

#### Option C: Command Line (Advanced)
```bash
cd portfolio-website
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/cosmobishal/cosmobishal.github.io.git
git branch -M main
git push -u origin main
```

### Step 5: Enable GitHub Pages
1. Go to repository → Settings → Pages
2. Source: "Deploy from a branch"
3. Branch: **main** / **(root)**
4. Click "Save"

### Step 6: Wait & Visit!
⏱️ Wait 2-5 minutes for deployment

🌐 Visit: `https://cosmobishal.github.io`

---

## ✏️ Quick Customizations

### Change Your Name
Edit `index.html`, find:
```html
<h1 class="glitch" data-text="BISHAL NEUPANE">BISHAL NEUPANE</h1>
```
Change to your name (keep it twice!)

### Update Email
Find this in `index.html`:
```html
<span>contact@bishalneupane.com</span>
```
Change to your email

### Add Your Photo (Optional)
1. Save your photo as `profile.jpg`
2. Put it in the `images` folder
3. Add to `index.html`:
```html
<img src="images/profile.jpg" alt="Your Name" class="profile-photo">
```

### Change Colors
Edit `css/styles.css`, find `:root` section:
```css
--primary-color: #00d9ff;  /* Change this! */
```

---

## 🎨 Customization Ideas

1. **Add Your ORCID**: Already in the code! Just update the link
2. **Update Certifications**: Edit `js/certifications.js`
3. **Add Publications**: Edit the publications section in `index.html`
4. **Change Profile Links**: Update LinkedIn, GitHub URLs

---

## 📱 Test Your Site

✅ Check these:
- [ ] All sections load
- [ ] Navigation works
- [ ] Stars are animating
- [ ] Mobile menu works
- [ ] Contact form appears
- [ ] All links work

---

## 🆘 Problems?

### Site not showing?
- Wait 10 minutes
- Check repository is public
- Check repository name is `yourusername.github.io`

### Stars not moving?
- Hard refresh: Ctrl+Shift+R (Windows) or Cmd+Shift+R (Mac)

### Something broken?
- Check browser console (F12)
- Compare your files with originals
- Re-upload files

---

## 📚 Full Documentation

See these files for more details:
- `README.md` - Full project overview
- `DEPLOYMENT.md` - Detailed deployment guide
- `DOCUMENTATION.md` - Complete technical documentation

---

## 🎉 Congratulations!

You now have a professional portfolio website!

**Share it with:**
- LinkedIn profile
- Resume
- Email signature
- Social media

**Next Steps:**
1. Add your own content
2. Update certifications regularly
3. Add new publications
4. Share your research

---

🌌 **Your journey to the stars begins here!** ✨

**Questions?** Check the documentation files or open an issue on GitHub.

**Need help?** Contact: [Your Email]

---

**Made with ❤️ for astronomy and science communication**
