# Images Folder

Add your images to this folder:

## Required Images

1. **favicon.png** (16x16 or 32x32 pixels)
   - Site icon that appears in browser tabs
   - PNG format recommended
   - See `favicon-guide.txt` in root directory for creation instructions

2. **og-image.jpg** (1200x630 pixels recommended)
   - Social media preview image
   - Shows when your site is shared on Facebook, Twitter, LinkedIn, etc.
   - JPG or PNG format

3. **profile.jpg** (Optional but recommended)
   - Your professional headshot
   - Use in About section if desired
   - Recommended size: 400x400 pixels or larger

## Certificates Subfolder

The `certificates/` folder is for storing images of your certification badges or documents:
- Add certification images here
- Reference them in `js/certifications.js` if you want to display them
- Supported formats: JPG, PNG, WebP

## Tips

- Keep images optimized for web (compress before uploading)
- Use descriptive filenames (e.g., `profile-bishal-neupane.jpg`)
- Recommended tools for image optimization:
  - TinyPNG (https://tinypng.com/)
  - Squoosh (https://squoosh.app/)
  - ImageOptim (Mac)

---

**Note**: This folder is currently empty. Add your images before deploying to GitHub Pages.
