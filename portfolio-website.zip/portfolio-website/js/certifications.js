// ============================================
// CERTIFICATIONS.JS - Certification Data & Filtering
// ============================================

const certifications = [
    // Machine Learning & AI
    {
        title: "5-Day AI Agents Intensive Course with Google",
        institution: "Kaggle",
        date: "December 2025",
        category: "ml",
        icon: "fa-brain"
    },
    {
        title: "Using AI/ML for Space Biology Research",
        institution: "NASA",
        date: "July 2025",
        category: "ml",
        icon: "fa-robot"
    },
    {
        title: "Gen AI Literacy Program",
        institution: "Elsevier",
        date: "June 2025",
        category: "ml",
        icon: "fa-microchip"
    },
    {
        title: "Introduction to Machine Learning for Earth Observation",
        institution: "EO College",
        date: "June 2025",
        category: "ml",
        icon: "fa-satellite-dish"
    },
    {
        title: "Career Essentials in Generative AI",
        institution: "Microsoft & LinkedIn",
        date: "May 2025",
        category: "ml",
        icon: "fa-graduation-cap"
    },
    {
        title: "Generative AI for Educators Certificate",
        institution: "Google",
        date: "May 2025",
        category: "ml",
        icon: "fa-chalkboard-teacher"
    },
    
    // Astronomy & Astrophysics
    {
        title: "IAU 7th Shaw Workshop",
        institution: "International Astronomical Union",
        date: "December 2025",
        category: "astronomy",
        icon: "fa-telescope"
    },
    {
        title: "Physics in An Astronomy Context",
        institution: "American Association of Physics Teachers",
        date: "November 2025",
        category: "astronomy",
        icon: "fa-atom"
    },
    {
        title: "Astronomy for Mental Health",
        institution: "IAU Office of Astronomy for Development",
        date: "November 2025",
        category: "astronomy",
        icon: "fa-heart"
    },
    {
        title: "Astrotourism for Development",
        institution: "IAU Office of Astronomy for Development",
        date: "November 2025",
        category: "astronomy",
        icon: "fa-mountain"
    },
    {
        title: "Astrophysics Subject Spotlight",
        institution: "Springpod",
        date: "July 2025",
        category: "astronomy",
        icon: "fa-star"
    },
    {
        title: "Astronomy for Development: Project Design",
        institution: "IAU Office of Astronomy for Development",
        date: "May 2025",
        category: "astronomy",
        icon: "fa-project-diagram"
    },
    {
        title: "Complexity Explorer",
        institution: "Santa Fe Institute",
        date: "June 2025",
        category: "astronomy",
        icon: "fa-network-wired"
    },
    {
        title: "Untracked Astrophotography",
        institution: "Thinkific",
        date: "June 2025",
        category: "astronomy",
        icon: "fa-camera"
    },
    {
        title: "World Science U Coursework",
        institution: "World Science Festival",
        date: "June 2025",
        category: "astronomy",
        icon: "fa-globe-americas"
    },
    {
        title: "Confronting The Big Questions: Highlights of Modern Astronomy",
        institution: "University of Rochester",
        date: "February 2025",
        category: "astronomy",
        icon: "fa-question-circle"
    },
    {
        title: "Knowing the Universe: History and Philosophy of Astronomy",
        institution: "University of Arizona",
        date: "February 2025",
        category: "astronomy",
        icon: "fa-book"
    },
    {
        title: "Astro 101: Black Holes",
        institution: "University of Alberta",
        date: "February 2025",
        category: "astronomy",
        icon: "fa-circle"
    },
    {
        title: "IVC2024: The Next Generation Survey of Multimessenger Astronomy",
        institution: "Institut Teknologi Bandung",
        date: "February 2025",
        category: "astronomy",
        icon: "fa-broadcast-tower"
    },
    {
        title: "Diploma in Celestial Navigation",
        institution: "Alison",
        date: "August 2024",
        category: "astronomy",
        icon: "fa-compass"
    },
    {
        title: "Countless Worlds in our Solar System: Asteroid/Comet/Meteor",
        institution: "Arizona State University",
        date: "August 2024",
        category: "astronomy",
        icon: "fa-meteor"
    },
    {
        title: "Openlearn Science & Technology Coursework",
        institution: "The Open University",
        date: "August 2024",
        category: "astronomy",
        icon: "fa-university"
    },
    {
        title: "Astronomy: Exploring Time and Space",
        institution: "Coursera",
        date: "August 2023",
        category: "astronomy",
        icon: "fa-clock"
    },
    {
        title: "Nuts and Bolts of Teaching Astronomy",
        institution: "Astronomical Society of the Pacific",
        date: "April 2025",
        category: "astronomy",
        icon: "fa-tools"
    },
    
    // Space Science & Technology
    {
        title: "Aerospace Work Experience",
        institution: "Airbus",
        date: "November 2025",
        category: "space",
        icon: "fa-plane"
    },
    {
        title: "NASA Open Science Essentials",
        institution: "NASA",
        date: "July 2025",
        category: "space",
        icon: "fa-rocket"
    },
    {
        title: "EU Space Programme Badge",
        institution: "EUSPA",
        date: "June 2025",
        category: "space",
        icon: "fa-satellite"
    },
    {
        title: "Overview of Space Science Technology and Application",
        institution: "ISRO",
        date: "June 2025",
        category: "space",
        icon: "fa-space-shuttle"
    },
    {
        title: "Outer Space",
        institution: "United Nations Office for Disarmament Affairs",
        date: "May 2025",
        category: "space",
        icon: "fa-globe"
    },
    {
        title: "Fundamentals of Remote Sensing",
        institution: "NASA",
        date: "May 2025",
        category: "space",
        icon: "fa-wifi"
    },
    {
        title: "NASA Open Science 101",
        institution: "NASA",
        date: "December 2024",
        category: "space",
        icon: "fa-flask"
    },
    {
        title: "Process & Lifetime of Space Mission",
        institution: "Arizona State University",
        date: "August 2024",
        category: "space",
        icon: "fa-tasks"
    },
    
    // Physics
    {
        title: "Quantum for All",
        institution: "International Year of Quantum Science and Technology",
        date: "October 2025",
        category: "physics",
        icon: "fa-atom"
    },
    {
        title: "II GRaSP - São Paulo's School of Gravitational Physics",
        institution: "ICTP",
        date: "August 2025",
        category: "physics",
        icon: "fa-wave-square"
    },
    {
        title: "Introduction to Plasma Physics and Fusion Energy",
        institution: "Princeton Plasma Physics Laboratory",
        date: "August 2025",
        category: "physics",
        icon: "fa-fire"
    },
    {
        title: "Basics of Quantum Physics",
        institution: "QURECA",
        date: "June 2025",
        category: "physics",
        icon: "fa-question"
    },
    {
        title: "Basics of Quantum Information",
        institution: "IBM",
        date: "May 2025",
        category: "physics",
        icon: "fa-info-circle"
    },
    {
        title: "CERN Solvay Education Program",
        institution: "CERN",
        date: "August 2024",
        category: "physics",
        icon: "fa-atom"
    },
    
    // Research & Professional Development
    {
        title: "Peer Review Excellence Online Training",
        institution: "IOP Publishing",
        date: "November 2025",
        category: "astronomy",
        icon: "fa-user-check"
    },
    {
        title: "Open Data Workshop 2025",
        institution: "National Science Foundation",
        date: "October 2025",
        category: "astronomy",
        icon: "fa-database"
    },
    {
        title: "Introduction to Project Cycle Management",
        institution: "ITCILO",
        date: "October 2025",
        category: "astronomy",
        icon: "fa-recycle"
    },
    {
        title: "Scopus Academy",
        institution: "Elsevier",
        date: "June 2025",
        category: "astronomy",
        icon: "fa-graduation-cap"
    },
    {
        title: "Inclusive Mindset: Tools for Building Positive Team Culture",
        institution: "Arizona State University",
        date: "August 2024",
        category: "astronomy",
        icon: "fa-users"
    },
    {
        title: "LaTeX Training",
        institution: "Eka Research",
        date: "2025",
        category: "astronomy",
        icon: "fa-file-code"
    },
    
    // Community Engagement & Outreach
    {
        title: "SciStarter Champion",
        institution: "SciStarter",
        date: "November 2025",
        category: "astronomy",
        icon: "fa-trophy"
    },
    {
        title: "Community Node of 100 Hours of Astronomy",
        institution: "IAU Office for Astronomy Outreach",
        date: "October 2025",
        category: "astronomy",
        icon: "fa-hands-helping"
    }
];

// Render certifications
function renderCertifications(filter = 'all') {
    const grid = document.getElementById('certifications-grid');
    if (!grid) return;
    
    const filtered = filter === 'all' 
        ? certifications 
        : certifications.filter(cert => cert.category === filter);
    
    grid.innerHTML = filtered.map(cert => `
        <div class="cert-card" data-category="${cert.category}">
            <div class="cert-icon">
                <i class="fas ${cert.icon}"></i>
            </div>
            <h3 class="cert-title">${cert.title}</h3>
            <p class="cert-institution">${cert.institution}</p>
            <p class="cert-date">${cert.date}</p>
        </div>
    `).join('');
}

// Filter functionality
function setupFilters() {
    const filters = document.querySelectorAll('.cert-filter');
    
    filters.forEach(filter => {
        filter.addEventListener('click', function() {
            // Remove active class from all filters
            filters.forEach(f => f.classList.remove('active'));
            
            // Add active class to clicked filter
            this.classList.add('active');
            
            // Get filter value and render
            const filterValue = this.getAttribute('data-filter');
            renderCertifications(filterValue);
        });
    });
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    renderCertifications();
    setupFilters();
});
