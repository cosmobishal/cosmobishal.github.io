// ============================================
// STARFIELD.JS - Animated Star Background
// ============================================

class Starfield {
    constructor() {
        this.canvas = document.getElementById('starfield');
        this.ctx = this.canvas.getContext('2d');
        this.stars = [];
        this.shootingStars = [];
        this.nebulaClouds = [];
        this.mouseX = 0;
        this.mouseY = 0;
        
        this.init();
    }
    
    init() {
        this.resize();
        this.createStars(200);
        this.createNebulaClouds(5);
        
        window.addEventListener('resize', () => this.resize());
        window.addEventListener('mousemove', (e) => {
            this.mouseX = e.clientX;
            this.mouseY = e.clientY;
        });
        
        this.animate();
        
        // Create shooting stars periodically
        setInterval(() => this.createShootingStar(), 3000);
    }
    
    resize() {
        this.canvas.width = window.innerWidth;
        this.canvas.height = document.documentElement.scrollHeight;
    }
    
    createStars(count) {
        for (let i = 0; i < count; i++) {
            this.stars.push({
                x: Math.random() * this.canvas.width,
                y: Math.random() * this.canvas.height,
                radius: Math.random() * 2,
                vx: (Math.random() - 0.5) * 0.2,
                vy: (Math.random() - 0.5) * 0.2,
                opacity: Math.random(),
                twinkleSpeed: Math.random() * 0.02 + 0.01
            });
        }
    }
    
    createNebulaClouds(count) {
        const colors = [
            'rgba(157, 78, 221, 0.03)',
            'rgba(0, 217, 255, 0.03)',
            'rgba(255, 71, 87, 0.03)',
            'rgba(123, 31, 162, 0.03)'
        ];
        
        for (let i = 0; i < count; i++) {
            this.nebulaClouds.push({
                x: Math.random() * this.canvas.width,
                y: Math.random() * this.canvas.height,
                radius: Math.random() * 200 + 100,
                color: colors[Math.floor(Math.random() * colors.length)],
                vx: (Math.random() - 0.5) * 0.1,
                vy: (Math.random() - 0.5) * 0.1
            });
        }
    }
    
    createShootingStar() {
        if (Math.random() > 0.5) {
            this.shootingStars.push({
                x: Math.random() * this.canvas.width,
                y: Math.random() * this.canvas.height / 2,
                length: Math.random() * 80 + 40,
                speed: Math.random() * 5 + 5,
                opacity: 1,
                angle: Math.PI / 4 + (Math.random() - 0.5) * 0.5
            });
        }
    }
    
    drawNebulaClouds() {
        this.nebulaClouds.forEach(cloud => {
            const gradient = this.ctx.createRadialGradient(
                cloud.x, cloud.y, 0,
                cloud.x, cloud.y, cloud.radius
            );
            
            gradient.addColorStop(0, cloud.color);
            gradient.addColorStop(1, 'rgba(0, 0, 0, 0)');
            
            this.ctx.fillStyle = gradient;
            this.ctx.fillRect(
                cloud.x - cloud.radius,
                cloud.y - cloud.radius,
                cloud.radius * 2,
                cloud.radius * 2
            );
            
            // Move clouds
            cloud.x += cloud.vx;
            cloud.y += cloud.vy;
            
            // Wrap around
            if (cloud.x < -cloud.radius) cloud.x = this.canvas.width + cloud.radius;
            if (cloud.x > this.canvas.width + cloud.radius) cloud.x = -cloud.radius;
            if (cloud.y < -cloud.radius) cloud.y = this.canvas.height + cloud.radius;
            if (cloud.y > this.canvas.height + cloud.radius) cloud.y = -cloud.radius;
        });
    }
    
    drawStars() {
        this.stars.forEach(star => {
            // Parallax effect based on mouse position
            const parallaxX = (this.mouseX - this.canvas.width / 2) * 0.01;
            const parallaxY = (this.mouseY - this.canvas.height / 2) * 0.01;
            
            const drawX = star.x + parallaxX * star.radius;
            const drawY = star.y + parallaxY * star.radius;
            
            // Twinkling effect
            star.opacity += (Math.random() - 0.5) * star.twinkleSpeed;
            star.opacity = Math.max(0.3, Math.min(1, star.opacity));
            
            // Draw star with glow
            this.ctx.beginPath();
            this.ctx.arc(drawX, drawY, star.radius, 0, Math.PI * 2);
            this.ctx.fillStyle = `rgba(255, 255, 255, ${star.opacity})`;
            this.ctx.fill();
            
            // Add glow for larger stars
            if (star.radius > 1) {
                const gradient = this.ctx.createRadialGradient(
                    drawX, drawY, 0,
                    drawX, drawY, star.radius * 3
                );
                gradient.addColorStop(0, `rgba(255, 255, 255, ${star.opacity * 0.5})`);
                gradient.addColorStop(1, 'rgba(255, 255, 255, 0)');
                
                this.ctx.fillStyle = gradient;
                this.ctx.fillRect(
                    drawX - star.radius * 3,
                    drawY - star.radius * 3,
                    star.radius * 6,
                    star.radius * 6
                );
            }
            
            // Move stars slightly
            star.x += star.vx;
            star.y += star.vy;
            
            // Wrap around screen
            if (star.x < 0) star.x = this.canvas.width;
            if (star.x > this.canvas.width) star.x = 0;
            if (star.y < 0) star.y = this.canvas.height;
            if (star.y > this.canvas.height) star.y = 0;
        });
    }
    
    drawShootingStars() {
        this.shootingStars = this.shootingStars.filter(star => {
            if (star.opacity <= 0) return false;
            
            const endX = star.x + Math.cos(star.angle) * star.length;
            const endY = star.y + Math.sin(star.angle) * star.length;
            
            // Create gradient for trail
            const gradient = this.ctx.createLinearGradient(
                star.x, star.y, endX, endY
            );
            gradient.addColorStop(0, `rgba(255, 255, 255, 0)`);
            gradient.addColorStop(0.5, `rgba(255, 255, 255, ${star.opacity})`);
            gradient.addColorStop(1, `rgba(255, 255, 255, ${star.opacity})`);
            
            this.ctx.strokeStyle = gradient;
            this.ctx.lineWidth = 2;
            this.ctx.beginPath();
            this.ctx.moveTo(star.x, star.y);
            this.ctx.lineTo(endX, endY);
            this.ctx.stroke();
            
            // Add glow
            this.ctx.shadowBlur = 10;
            this.ctx.shadowColor = 'rgba(255, 255, 255, 0.8)';
            this.ctx.stroke();
            this.ctx.shadowBlur = 0;
            
            // Move shooting star
            star.x += Math.cos(star.angle) * star.speed;
            star.y += Math.sin(star.angle) * star.speed;
            star.opacity -= 0.01;
            
            return true;
        });
    }
    
    drawConstellations() {
        // Draw simple constellation lines between nearby stars
        this.ctx.strokeStyle = 'rgba(100, 200, 255, 0.1)';
        this.ctx.lineWidth = 0.5;
        
        for (let i = 0; i < this.stars.length; i++) {
            for (let j = i + 1; j < this.stars.length; j++) {
                const dx = this.stars[i].x - this.stars[j].x;
                const dy = this.stars[i].y - this.stars[j].y;
                const distance = Math.sqrt(dx * dx + dy * dy);
                
                if (distance < 100 && Math.random() > 0.98) {
                    this.ctx.beginPath();
                    this.ctx.moveTo(this.stars[i].x, this.stars[i].y);
                    this.ctx.lineTo(this.stars[j].x, this.stars[j].y);
                    this.ctx.stroke();
                }
            }
        }
    }
    
    animate() {
        // Clear canvas
        this.ctx.fillStyle = '#0a0a0f';
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
        
        // Draw layers
        this.drawNebulaClouds();
        this.drawConstellations();
        this.drawStars();
        this.drawShootingStars();
        
        requestAnimationFrame(() => this.animate());
    }
}

// Initialize starfield when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new Starfield();
});
